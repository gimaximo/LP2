﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";
            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Entre com o número {i + 1}", "Entrada de dados");
                if (auxiliar == "")
                    return;
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
                else // conversão ok
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);

            //usando reverse
            /*Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
                auxiliar += x + "\n";
            MessageBox.Show(auxiliar);

            // for ao contrario
            auxiliar = "";
            for (var j = 19; j >= 0; j--)
                auxiliar += vetor[j] + "\n";
            MessageBox.Show(auxiliar);*/
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[2, 2];
            string auxiliar = "";
            double[] medias = new double[2];
            string aux = "";

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    auxiliar = Interaction.InputBox($"Entre com a nota {i + 1} do aluno {j + 1}", "Entrada de dados");
                    if (auxiliar == "")
                        return;
                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Número inválido!");
                        i--;
                    }
                    else
                    {
                        if (notas[i, j] < 0 || notas[i, j] > 10)
                        {
                            MessageBox.Show("Número inválido!");
                            i--;
                        }
                        else
                        {
                            medias[i] = medias[i] + notas[i, j];
                        }
                    }
                }
                medias[i] = medias[i] / 2;
            }
            for (int i = 0; i < 2; i++)
                aux = aux + "aluno" +i + ": media" +medias[i].ToString("N2");
            MessageBox.Show(aux);
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Carlos", "Ronaldo", "Elaine", "Danilo", "Vanessa",
                "Thiago", "Ana", "Maria", "João"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList() { "Ana", "Carlos", "Elaine", "Danilo", "João", "Otávio", "Maria", "Ronaldo", "Vanessa", "Thiago" };
            alunos.Remove("Otávio");
            string novaSaida = "";
            foreach (var x in alunos)
            {
                novaSaida += x.ToString() + "; \n";
            }
            MessageBox.Show(novaSaida);
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            Exercicio5 form2 = new Exercicio5();
            form2.Show();
        }
    }
}
