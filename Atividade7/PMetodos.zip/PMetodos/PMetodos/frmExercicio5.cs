﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void BtnSorteio_Click(object sender, EventArgs e)
        {
            int num1;
            int num2;

            if(!int.TryParse(txtNumero1.Text, out num1) ||
                !int.TryParse(txtNumero2.Text, out num2))
            {
                MessageBox.Show("Dados inválidos");
            }
            else
            {
                if((num1 <= 0) || (num2 <= 0) || (num1 >= num2))
                {
                    MessageBox.Show("Primeiro número deve ser menor que o segundo");
                }
                else
                {
                    Random objR = new Random();
                    int aleatorio = objR.Next(num1, num2);
                    MessageBox.Show("O número aleatório é: "+aleatorio);
                }
            }
        }
    }
}
