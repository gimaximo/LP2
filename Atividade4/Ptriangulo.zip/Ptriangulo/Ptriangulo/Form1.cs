﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtVal1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtVal1, "");
            double val1;

            if (!double.TryParse(txtVal1.Text, out val1))
            {
                errorProvider1.SetError(txtVal1, "valor 1 inválido");
            }


        }

        private void TxtVal2_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtVal2, "");
            double val2;

            if (!double.TryParse(txtVal2.Text, out val2))
            {
                errorProvider2.SetError(txtVal2, "valor 2 inválido");
            }
        }

        private void TxtVal3_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtVal3, "");
            double val3;

            if (!double.TryParse(txtVal3.Text, out val3))
            {
                errorProvider3.SetError(txtVal3, "valor 3 inválido");
            }
        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            double val1 = 0, val2 = 0, val3 = 0;
            if (!double.TryParse(txtVal1.Text, out val1) ||
                !double.TryParse(txtVal2.Text, out val2) ||
                !double.TryParse(txtVal3.Text, out val3))
            {
                MessageBox.Show("valores devem ser numéricos");
            }
            else
            {
                if (val1 < (val2 + val3) && val1 >
                    Math.Abs(val2 - val3) && val2 < (val1 + val3)
                    && val2 > Math.Abs(val1 - val3)
                    && val3 < (val1 + val2) &&
                    val3 > Math.Abs(val1 - val2))
                {
                    if (val1 == val2 && val2 == val3)
                        MessageBox.Show($"os valores {val1}, {val2} e {val3} formam um triângulo equilátero");
                    else
                    {
                        if (val1 == val2 || val1 == val3 || val3 == val2)
                            MessageBox.Show($"os valores {val1}, {val2} e {val3} formam um triângulo isósceles");
                        else
                            MessageBox.Show($"os valores {val1}, {val2} e {val3} formam um triângulo escaleno");

                    }
                }
            }
        }

        private void BtnLimp_Click(object sender, EventArgs e)
        {
            txtVal1.Text = "";
            txtVal2.Text = "";
            txtVal3.Text = "";
            txtVal1.Focus();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja realmente sair?",
               "Saída", MessageBoxButtons.YesNo,
               MessageBoxIcon.Question) ==
               DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
